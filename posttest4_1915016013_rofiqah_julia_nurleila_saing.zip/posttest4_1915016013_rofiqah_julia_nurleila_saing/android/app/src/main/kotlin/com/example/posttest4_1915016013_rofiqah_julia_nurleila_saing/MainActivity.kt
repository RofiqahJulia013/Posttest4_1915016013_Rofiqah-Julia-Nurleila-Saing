package com.example.posttest4_1915016013_rofiqah_julia_nurleila_saing

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
